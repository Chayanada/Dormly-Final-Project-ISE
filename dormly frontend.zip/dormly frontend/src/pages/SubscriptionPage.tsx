import NotAvailable from '../components/common/NotAvailable';

export default function SubscriptionPage() {
    return <NotAvailable />;
}