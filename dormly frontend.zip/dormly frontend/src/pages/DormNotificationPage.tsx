import NotAvailable from '../components/common/NotAvailable';

export default function DormNotificationPage() {
    return <NotAvailable />;
}