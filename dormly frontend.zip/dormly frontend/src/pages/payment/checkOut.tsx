// import React, { useState } from 'react';
// import './checkOut.css';
// import { type Page, type DormDataForPayment } from '../../App';
// import { FaRegCreditCard } from "react-icons/fa6";
// import { BsBank2 } from "react-icons/bs";
// import { IoQrCode } from "react-icons/io5";

// const paymentOptions = [
//   { id: 'card', name: 'CreditCard', icon: FaRegCreditCard, targetPage: 'paymentCard' as Page },
//   { id: 'mobile_banking', name: 'Mobile banking', icon: BsBank2, targetPage: 'mobileBanking' as Page },
//   { id: 'qrPayment', name: 'QR Payment', icon: IoQrCode, targetPage: 'qrPayment' as Page }
// ];

// // ใน CheckOut.tsx
// export default function CheckOut({ navigateTo, dormData }: CheckoutProps) {
//   // component logic
// }
// interface CheckoutProps {
//   navigateTo: (page: Page) => void;
//   dormData: DormDataForPayment;
// }

// const Checkout: React.FC<CheckoutProps> = ({ navigateTo, dormData }) => {
//   const [selectedOption, setSelectedOption] = useState<string>('card');

//   if (!dormData || !dormData.room_types || dormData.room_types.length === 0) {
//     return <div>Error: Dorm data is missing. (checkOut.tsx)</div>;
//   }

//   const productPrice = dormData.room_types[0].rent_per_month;
//   const productImage = dormData.medias[0] || 'https://images.unsplash.com/photo-1570129477490-d5e03a0c5b59?q=80&w=400';

//   const handleNextClick = () => {
//     const selected = paymentOptions.find(opt => opt.id === selectedOption);
//     if (selected) {
//       if (selected.targetPage === 'checkout') {
//         alert('This payment method is not available yet.');
//         return;
//       }
   
//       navigateTo(selected.targetPage);
//     }
//   };

//   return (
//     <div className="checkout-container">
//       <h1 className="checkout-title">Checkout</h1>

//       <div className="order-summary">
//         <img src={productImage} alt={dormData.dorm_name} className="product-image" />
//         <div className="product-details">
//           <h3>{dormData.dorm_name}</h3>
//           <p>Monthly Rental</p>
//         </div>
//         <div className="product-price">
//           {productPrice.toLocaleString()} THB
//         </div>
//       </div>

//       <hr className="divider" />

//       <h2 className="payment-title">Select your payment option</h2>
//       <div className="payment-options-list">
//         {paymentOptions.map((option) => (
//           <button
//             key={option.id}
//             className={`payment-option ${selectedOption === option.id ? 'selected' : ''}`}
//             onClick={() => setSelectedOption(option.id)}
//           >
//             <option.icon className="payment-icon" />
//             <span className="payment-name">{option.name}</span>
//           </button>
//         ))}
//       </div>

//       <div className="checkout-footer">
//         <button className="next-button" onClick={handleNextClick}>
//           Next
//         </button>
//       </div>
//     </div>
//   );
// };

// export default Checkout;

// // src/pages/payment/checkOut.tsx

// // import React from "react";
// // import "./checkOut.css";

// // interface DormDataForPayment {
// //   dorm_id: number;
// //   dorm_name: string;
// //   medias: string[];
// //   room_types?: { rent_per_month: number }[];
// // }

// // type Page =
// //   | "checkout"
// //   | "paymentCard"
// //   | "mobileBanking"
// //   | "qrPayment"
// //   | "success"
// //   | "fail";

// // interface CheckoutProps {
// //   navigateTo: (page: Page) => void;
// //   dormData: DormDataForPayment;
// // }

// // const Checkout: React.FC<CheckoutProps> = ({ navigateTo, dormData }) => {
// //   // TODO: เอา UI ของ Checkout ตัวจริงของคุณมาใส่แทนด้านล่างนี้ได้เลย
// //   return (
// //     <div>
// //       <h1>Checkout</h1>
// //       <p>{dormData.dorm_name}</p>

// //       <button onClick={() => navigateTo("paymentCard")}>
// //         ชำระด้วยบัตรเครดิต
// //       </button>
// //       <button onClick={() => navigateTo("mobileBanking")}>
// //         Mobile Banking
// //       </button>
// //       <button onClick={() => navigateTo("qrPayment")}>
// //         QR Payment
// //       </button>
// //     </div>
// //   );
// // };

// // export default Checkout;



// //2
// // import React from "react";
// // import { useNavigate } from "react-router-dom";
// // import "./checkOut.css";

// // interface DormDataForPayment {
// //   dorm_id: number;
// //   dorm_name: string;
// //   medias: string[];
// //   room_types?: { rent_per_month: number }[];
// // }

// // type Page =
// //   | "checkout"
// //   | "paymentCard"
// //   | "mobileBanking"
// //   | "qrPayment"
// //   | "success"
// //   | "fail";

// // interface CheckoutProps {
// //   navigateTo: (page: Page) => void;
// //   dormData: DormDataForPayment;
// // }

// // const Checkout: React.FC<CheckoutProps> = ({ navigateTo, dormData }) => {
// //   const navigate = useNavigate();

// //   const handleClose = () => {
// //     // เลือกได้ว่าจะกลับหน้าจอง หรือย้อนกลับหน้าเดิม
// //     // navigate(-1); // กลับหน้าก่อนหน้า
// //     navigate("/reserved"); // แนะนำให้กลับหน้าสถานะการจอง
// //   };

// //   return (
// //     <div className="min-h-screen bg-gray-50 flex justify-center items-center">
// //       <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-2xl relative">
// //         {/* ปุ่มปิดมุมขวาบน */}
// //         <button
// //           onClick={handleClose}
// //           className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 text-xl"
// //         >
// //           ×
// //         </button>

// //         <h1 className="text-2xl font-bold mb-4">
// //           ชำระมัดจำสำหรับ {dormData.dorm_name}
// //         </h1>

// //         {/* เนื้อหาอื่นๆ ของ checkout ตามที่คุณมี */}
// //         {/* ... */}

// //         <div className="mt-6 flex gap-3 justify-end">
// //           <button
// //             onClick={handleClose}
// //             className="px-4 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 text-sm font-medium"
// //           >
// //             ยกเลิก
// //           </button>

// //           <button
// //             onClick={() => navigateTo("paymentCard")}
// //             className="px-4 py-2 rounded-lg bg-purple-600 text-white hover:bg-purple-700 text-sm font-semibold"
// //           >
// //             ไปหน้าชำระเงิน
// //           </button>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // };

// // export default Checkout;


import React, { useState } from 'react';
import './checkOut.css';
import { type Page, type DormDataForPayment } from '../../App';
import {
  FiCreditCard,
  FiPieChart,
  FiSmartphone,
  FiGrid
} from 'react-icons/fi';

const paymentOptions = [
  { id: 'card', name: 'Card', icon: FiCreditCard, targetPage: 'paymentCard' as Page },
  { id: 'mobile_banking', name: 'Mobile banking', icon: FiSmartphone, targetPage: 'mobileBanking' as Page },
  { id: 'qrPayment', name: 'QR Payment', icon: FiGrid, targetPage: 'qrPayment' as Page },
  { id: 'installment', name: 'Installment', icon: FiPieChart, targetPage: 'checkout' as Page }, // ยังไม่เปิดใช้งาน
];

interface CheckoutProps {
  navigateTo: (page: Page) => void;
  dormData: DormDataForPayment;
}

const Checkout: React.FC<CheckoutProps> = ({ navigateTo, dormData }) => {
  const [selectedOption, setSelectedOption] = useState<string>('card');

  if (!dormData || !dormData.room_types || dormData.room_types.length === 0) {
    return (
      <div className="checkout-container">
        <h1 className="checkout-title">Error</h1>
        <p>ไม่พบข้อมูลหอพัก (checkOut.tsx)</p>
      </div>
    );
  }

  const productPrice = dormData.room_types[0].rent_per_month;
  const productImage =
    dormData.medias && dormData.medias.length > 0
      ? dormData.medias[0]
      : 'https://placehold.co/400x300/e2e8f0/94a3b8?text=Dorm';

  const handleNextClick = () => {
    const selected = paymentOptions.find((opt) => opt.id === selectedOption);
    if (!selected) return;

    // installment ยังไม่ให้ใช้
    if (selected.targetPage === 'checkout') {
      alert('This payment method is not available yet.');
      return;
    }

    navigateTo(selected.targetPage);
  };

  return (
    <div className="checkout-container">
      <h1 className="checkout-title">Checkout</h1>

      {/* Order Summary */}
      <div className="order-summary">
        <img
          src={productImage}
          alt={dormData.dorm_name}
          className="product-image"
        />
        <div className="product-details">
          <h3>{dormData.dorm_name}</h3>
          <p>Monthly Rental</p>
        </div>
        <div className="product-price">
          {productPrice.toLocaleString()} THB
        </div>
      </div>

      <hr className="divider" />

      {/* Payment Options */}
      <h2 className="payment-title">Select your payment option</h2>
      <div className="payment-options-list">
        {paymentOptions.map((option) => (
          <button
            key={option.id}
            className={`payment-option ${
              selectedOption === option.id ? 'selected' : ''
            }`}
            onClick={() => setSelectedOption(option.id)}
          >
            <option.icon className="payment-icon" />
            <span className="payment-name">{option.name}</span>
          </button>
        ))}
      </div>

      {/* Footer */}
      <div className="checkout-footer">
        <button className="next-button" onClick={handleNextClick}>
          Next
        </button>
      </div>
    </div>
  );
};

export default Checkout;
