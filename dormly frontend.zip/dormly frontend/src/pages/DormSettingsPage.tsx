import NotAvailable from '../components/common/NotAvailable';

export default function DormSettingsPage() {
    return <NotAvailable />;
}
